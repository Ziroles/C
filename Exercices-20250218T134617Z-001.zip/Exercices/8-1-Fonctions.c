#include "8-1-Fonctions.h"

float max(float a, float b) {
    return a>b?a:b;
}