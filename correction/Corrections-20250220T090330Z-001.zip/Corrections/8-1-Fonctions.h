#pragma once

float max(float a, float b);